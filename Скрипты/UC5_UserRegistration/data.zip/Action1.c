Action1()
{

	lr_start_transaction("StartPage");

	return 0;
}